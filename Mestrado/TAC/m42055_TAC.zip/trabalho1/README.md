COMANDOS:

- make run-1 -> criar ficheiro de exemplo twice.ir
- make run-2 -> criar ficheiro de exemplo triangular.ir
- make run-3 -> criar ficheiro de exemplo g.ir
- make run-4 -> criar ficheiro de exemplo factorial.ir
- make run-5 -> criar ficheiro de exemplo fig-9.ir
- make run-6 -> criar ficheiro de exemplo fibonacci-v2.ir
- make run-7 -> criar ficheiro de exemplo procedure.ir

- make run-all -> criar ficheiros com todos os exemplos

- make clean -> eliminar ficheiros de compilação


NOTA:

- Os ficheiros são guardados na pasta examples

